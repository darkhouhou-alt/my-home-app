# 우리집 2인 라이프 (Vercel + Upstash Redis 배포 패키지)

Vercel에 바로 올려서 두 사람이 각자 기기에서 실시간으로 데이터를 공유할 수 있는 배포 패키지입니다.

## 배포 순서 (약 3분, 무료 플랜 가능)

1. 이 폴더를 GitHub 저장소에 올린 뒤 **Vercel**에서 **New Project**로 가져옵니다. (또는 터미널에서 `npx vercel` 실행)
2. Vercel 프로젝트 대시보드 상단 **Storage** 탭 → **Create Database** → **Upstash (Redis)** 무료 플랜을 선택해 프로젝트에 연결합니다. (`UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN`이 자동 등록됩니다.)
3. **Deployments** 탭에서 **Redeploy**를 한 번 누르면 완료!
4. 생성된 `https://프로젝트명.vercel.app` 주소를 상대방에게 보내면 두 분이 실시간으로 함께 사용하실 수 있습니다.
